import { Component } from '@angular/core';
import { RegisterComponent } from './user/components/register/register.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Course Management System';
}
