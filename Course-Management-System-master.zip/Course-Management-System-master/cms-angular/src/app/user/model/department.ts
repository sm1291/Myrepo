export class Department {
    deptName: String;
    building: String;
    constructor() {
        this.deptName='';
        this.building='';
    }
}
