export class Assignment {
      fileName : string;
	   CourseName: String;
       studentId: String;
       Assignment() {
        this.fileName = '';
        this.CourseName = '';
        this.studentId = '';
       }
}
