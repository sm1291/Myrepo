package com.unt.coursemanagentsys.util;

public class Department {
private String deptName;
private String building;
public String getDeptName() {
	return deptName;
}
public void setDeptName(String deptName) {
	this.deptName = deptName;
}
public String getBuilding() {
	return building;
}
public void setBuilding(String building) {
	this.building = building;
}
}
